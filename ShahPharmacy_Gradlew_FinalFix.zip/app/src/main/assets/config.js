// Shah Pharmacy Supabase configuration
// This is the public/publishable client key. NEVER put a service_role/secret key here.
window.SHAH_CLOUD = {
  url: 'https://ssbwcsvjqsdyzlbijzfw.supabase.co',
  anonKey: 'sb_publishable_loFn69KUseNMBy9d436-1w_3QR1eut6'
};
