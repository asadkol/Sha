# Shah Pharmacy Android

Android WebView + SQLite pharmacy management app.

## Build

The project includes `gradlew`/`gradlew.bat` launchers. On GitHub Actions, Gradle 8.9 is installed automatically, so run:

```bash
./gradlew assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

Note: this repository uses a lightweight Gradle launcher rather than the binary Gradle Wrapper JAR. The GitHub Actions workflow installs Gradle 8.9 before calling `./gradlew`.
